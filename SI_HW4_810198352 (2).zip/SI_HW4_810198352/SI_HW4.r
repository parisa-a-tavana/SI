install.packages("boot")
library(boot)

######8
df=read.csv("/content/Diet.csv")
head(df)

#####a
df$weight_loss<-df$pre.weight - df$weight6weeks
boxplot(weight_loss ~ Diet, data = df)

#####b,c
one_way <- aov(weight_loss ~ Diet, data = df)

summary(one_way)

###d
pairwise.t.test(df$weight_loss, df$Diet, p.adjust.method="bonferroni")

#######9
#####a
df=read.csv("/content/Houses.csv")
head(df)

df_berlin<-df[df$City == 'Berlin', ]
df_london<-df[df$City == 'London', ]
bootstrapCI2 <- function(data1, data2, nsim){
  n1 <- length(data1)
  n2 <- length(data2)
  
  bootCI2 <- c()
  
  for(i in 1:nsim){
    bootSamp1 <- sample(1:n1, n1, replace=TRUE) 
    bootSamp2 <- sample(1:n2, n2, replace=TRUE)
    thisXbar <- mean(data1[bootSamp1])-mean(data2[bootSamp2])
    bootCI2 <- c(bootCI2, thisXbar) 
  }
  
  return(bootCI2)
}

Boot_mean_diff_berlin_london <- bootstrapCI2(df_berlin$Area..Meter., df_london$Area..Meter., nsim=1000)
hist(Boot_mean_diff_berlin_london)

##########b,c
t.test(Boot_mean_diff_berlin_london,mu= 0)
t.test(df_berlin$Area..Meter., df_london$Area..Meter.)
