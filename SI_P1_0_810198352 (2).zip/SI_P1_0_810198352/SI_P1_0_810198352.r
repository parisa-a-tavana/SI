install.packages("ggplot2") 
install.packages("scales")
install.packages("dplyr")  
install.packages("tidyverse")    
install.packages("naniar") 
install.packages("rgl") 
install.packages("ggExtra")
install.packages("plotly")
install.packages("pwr")
install.packages("caret")
install.packages("reshape2")
install.packages("hexbin")
install.packages("ggmosaic")
devtools::install_github('alanarnholt/BSDA')
install.packages("GGally")
library(GGally)
library("BSDA")                  
library("ggplot2")
library("tidyverse")
library("naniar")
library("dplyr")
library("rgl")
library("plotly") 
library("reshape2")
library("pwr")
library("caret")
library("hexbin")
library("ggmosaic")
###Q0
####B
df=read.csv('/content/nonvoters_data.csv')
print(paste("number of variables:", as.character(length(df))))
print(paste("number of cases:", as.character(length(df[,1]))))
#####C
print("columns with NA values")
print(names(which(colSums(is.na(df))>0)))
df[is.na(df)] = 0
print("columns with NA values")
print(names(which(colSums(is.na(df))>0)))
df[df == -1] <- NA
print("columns with negative values")
print(names(which(colSums(is.na(df))>0)))
df <- df %>% 
  mutate(Q22 = coalesce(Q22, 0),
         Q28_1 = coalesce(Q28_1, 0),Q28_2 = coalesce(Q28_2, 0),Q28_3 = coalesce(Q28_3, 0),Q28_4 = coalesce(Q28_4, 0),Q28_5 = coalesce(Q28_5, 0),Q28_6 = coalesce(Q28_6, 0),Q28_7 = coalesce(Q28_7, 0),Q28_8 = coalesce(Q28_8, 0),
         Q29_1 = coalesce(Q29_1, 0),Q29_2 = coalesce(Q29_2, 0),Q29_3 = coalesce(Q29_3, 0),Q29_4 = coalesce(Q29_4, 0),Q29_5 = coalesce(Q29_5, 0),Q29_6 = coalesce(Q29_6, 0),Q29_7 = coalesce(Q29_7, 0),Q29_8 = coalesce(Q29_8, 0),Q29_9 = coalesce(Q29_9, 0),Q29_10 = coalesce(Q29_10, 0),   
         Q31 = coalesce(Q31, 0),Q32 = coalesce(Q32, 0),Q33 = coalesce(Q33, 0))
missing_prop<-apply(df, 2, function(col)sum(is.na(col))/length(col))
missing_prop<-data.frame(missing_prop[!(missing_prop==0)])
print("portion of missing values for each variable")
missing_prop
calc_mode <- function(x){
  distinct_values <- unique(x)
  distinct_tabulate <- tabulate(match(x, distinct_values))
  distinct_values[which.max(distinct_tabulate)]
}

df<-df %>% 
  mutate(across(everything(), ~replace_na(.x, calc_mode(.x))))

names <- c(3:113,115:119)
df[,names] <- lapply(df[,names] , factor)
df$RespId<-as.character(df$RespId)
print("variables that should be eliminated:")
print(names(which(colSums(is.na(df))>0)))
df<-select(df, -c(Q19_1, Q19_4, Q19_5, Q19_7, Q19_8, Q19_9, Q19_10))
###D
print("the final dataset")
head(df)

                    
                    

###################Q1
###A
bin_size=(max(df$weight)-min(df$weight))/(sqrt(length(df$weight)))
ggplot(df, aes(x=weight)) +                                
  geom_histogram(aes(y = stat(density)),binwidth = bin_size) +
  geom_density(col = "red")+
  
  geom_vline(xintercept = mean(x=df$weight),col = "green",lwd = 1, linetype="dotted")+geom_vline(xintercept = median(x=df$weight),col = "blue",lwd = 1, linetype="dotted")+labs(title="weight histogram and fitted normal density")
####C
ggplot(data = df, aes(x ="", y = weight)) + stat_boxplot(geom = 'errorbar')+geom_boxplot(outlier.size=0.5) +labs(title="weight boxplot")

###E
df_vars=data.frame("mean"=mean(df$weight), "variance"=var(df$weight),"median"=median(df$weight),"standard deviation"=sd(df$weight))
print(df_vars)

###F
a<-quantile(df$weight)
weight_cats<-data.frame(weight=cut(df$weight,breaks=c(a[1],a[2],a[3],a[4],a[5]),labels=c("22_35","36_53","54_64","65_94"),right=FALSE))
n=length(weight_cats$weight)
n_c<-c(length(weight_cats[weight_cats$weight=="22_35",]),length(weight_cats[weight_cats$weight=="36_53",]),length(weight_cats[weight_cats$weight=="54_64",]),length(weight_cats[weight_cats$weight=="65_94",]))
p_c<-(n_c/n)*100
df_weight_nums<-data.frame(Frequency=n_c,percent=p_c,gorup=c("22_35","36_53","54_64","65_94"))

df_weight_nums


ggplot(df_weight_nums, aes(x = "", y = Frequency, fill = gorup)) +geom_col() +coord_polar(theta = "y")+theme_void()+geom_text(aes( label = scales::percent(percent,scale = 1)), color="black",position = position_stack(vjust=0.5)) +labs(title="Pie chart of weight in four categories ")

##G
ggplot(df, aes(x = weight)) +
  geom_density(color = 4,
               fill = 4,
               alpha = 0.25)+
  geom_vline(xintercept = mean(x=df$weight),       
             col = "green",
             lwd = 1, linetype="dotted")+
  geom_text(aes(x=mean(x=weight)+0.35, label=paste("Mean\n",mean(x=weight)), y=1),colour="green",size = 3.5)+
  geom_vline(xintercept = median(x=df$weight),      
             col = "red",
             lwd = 1, linetype="dotted")+
             geom_text(aes(x=median(x=weight)-0.35, label=paste("Median\n",median(x=weight)), y=0.5),colour="red",size = 3.5)+
             labs(title="weight density plot")


###################Q
###A
voter_table<-table(df$voter_category)
df_count<-data.frame(voter_table)

colnames(df_count)[1] ="voter_category"
colnames(df_count)[2] ="count"

prob_table <- (voter_table / sum(voter_table))*100
df_freq<-data.frame(prob_table)
colnames(df_freq)[1] ="voter_category"
colnames(df_freq)[2] ="frequency"

df_count$frequency<-df_freq$frequency
print("Voter Category Frequency Table")
df_count;
####B
ggplot(df_count, aes(reorder(voter_category, count), count, fill = voter_category)) +   
geom_bar(stat = "identity")+
coord_flip()+
labs(x= "frequency", y = "voter regularity categories",title="Horizontal bar plot of voter regularity category");
#####C
ggplot(df_count, aes(reorder(voter_category, frequency), frequency, fill = voter_category,label =scales::percent(frequency,scale = 1)  )) +   
scale_y_continuous(labels = scales::percent_format(scale = 1))+
geom_bar(stat = "identity")+
geom_text(nudge_y= -.03,color="black",size = 3)+
labs(x= "voter regularity categories", y = "frequency")+
ggtitle("barplot of voter regularity category")
#####D
ggplot(df, aes(x=weight, y=voter_category)) +
  geom_violin(draw_quantiles = c(0.25, 0.5, 0.75),aes(fill= voter_category))+
  ggtitle("violine plot of weight density in voter regularity category ")


##################Q3
####A
options(repr.plot.width=15,repr.plot.height=10)
ggplot(df, aes(x=ppage, y=weight)) + 
    geom_point(size=0.7,alpha=0.5) +
      scale_color_manual(values="purple")+
      ggtitle("scatter plot between age and weight")
####B
options(repr.plot.width=15,repr.plot.height=10)
ggplot(df, aes(x=ppage, y=weight,color = Q30)) + 
    geom_point(size=0.7,alpha=0.4) +
    scale_color_manual(values = c("red", "blue", "orange","yellow","green"),labels = c("Republican", "Democrat","Independent","Another party","No preference"))+
    ggtitle("scatter plot between age and weight with different party supporters")
###C
p_w_cor<-cor(df$ppage, df$weight, method="spearman")
p_w_cor<-format(round(p_w_cor, 4), nsmall = 4)
print(paste("correlation coefficient between age and weight:",as.character(p_w_cor)))
cor.test(df$ppage,df$weight,method="pearson")
####D
p<-ggplot(df, aes(x=ppage, y=weight) ) + geom_hex()+stat_bin_hex(binwidth=c(0.008,0.008))+geom_point(alpha=0)+ggtitle("hexbin plot with marginal density")
ggMarginal(p, type = "histogram")
p<-ggplot(df, aes(x=ppage, y=weight) ) + geom_hex()+stat_bin_hex(binwidth=c(0.25,0.25))+geom_point(alpha=0)+ggtitle("hexbin plot with marginal density with larger bin size")
ggMarginal(p, type = "histogram")
####E
ggplot(df, aes(x = ppage, y = weight))+geom_bin2d(bins=70)+ xlab("age") + ylab("weight") +ggtitle("2D density plot")

###################Q4
#####A
df_corr <- data.frame (age  = df$ppage,weight = df$weight, vote_time_period=as.numeric(df$Q26), oppose_systematic_race_problem_exists=as.numeric(df$Q3_1))
cor_data = cor(df_corr)
melted_cormat <- melt(cor_data)
ggplot(data = melted_cormat, aes(x=Var1, y=Var2, fill=value)) + 
  geom_tile() +
  geom_text(aes(Var2, Var1, label = value), size = 5) +
  scale_fill_gradient2(low = "blue", high = "red",
                       limit = c(-1,1), name="Correlation") +
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.background = element_blank())+
          ggtitle("heatmap correlogram")
##B
ggpairs(df_corr, columns = 1:4,aes(color = "red"),
 upper = list(continuous = "points"),lower = list(continuous = "points"),diag = list(continuous = "blankDiag"))+
   ggtitle("heatmap correlogram")
###C
df_corr$race<-df$race
plot_ly(df_corr,x=~age,y=~weight,z=~vote_time_period,marker=list(size=2)) %>%add_markers(color=~race)%>%layout(title = '3d plot')


####################Q5
####A
print("Contingency Table: ")
tavl<-table(df$income_cat,df$educ)
tavl
####B
ggplot(df, aes(x = income_cat,group=educ,fill =educ )) +
geom_bar(position = "dodge") +
geom_text(mapping = aes(label = after_stat(count)),vjust = "bottom",position = position_dodge(.9),stat = "count") +        
ggtitle("grouped bar chart of income and education")
###C
ggplot(df, aes(x =income_cat ,group=educ,fill =educ )) +
geom_bar() +
geom_text(mapping = aes(label = after_stat(count)),position="stack",stat = "count") +        
ggtitle("segmented bar chart of income and education")
####D
ggplot(data = df) +geom_mosaic(aes(x = product(educ,income_cat), fill=educ))+theme_mosaic()


#######################Q6
####B
df_smple_some<-df[sample(nrow(df),25),]

process_age <- preProcess(as.data.frame(df_smple_some$ppag), method=c("range"))
sample_age <- predict(process_age, as.data.frame(df_smple_some$ppag))
colnames(sample_age)[1]<-"age"

process_weight <- preProcess(as.data.frame(df_smple_some$weight), method=c("range"))
sample_weight <- predict(process_weight, as.data.frame(df_smple_some$weight))
colnames(sample_weight)[1]<-"weight"

sample_all<-merge(sample_weight, sample_age)

t.test(sample_all$weight, sample_all$age,conf.level = 0.95,var.equal = FALSE,alternative = "less" )


###################Q7
####A
df_smple<-df[sample(nrow(df),100),]
n=length(df_smple$weight)
s=sd(df_smple$weight)
x_mean=mean(df_smple$weigh)
z=qnorm(1-(1-0.98)/2)
lower_bound=x_mean-(z * (s/sqrt(n))   )
upper_bound=x_mean+(z * (s/sqrt(n))   )
print(paste("mean 98% confidence interval: ",as.character(lower_bound),",",as.character(upper_bound ),""))
####C
options(repr.plot.width=15,repr.plot.height=8)
bin_size=(max(df_smple$weight)-min(df_smple$weight))/(sqrt(length(df_smple$weight)))
ggplot(df_smple, aes(x=weight)) +                                
  geom_histogram(aes(y = stat(density)),binwidth = bin_size) +
  
  geom_vline(xintercept = mean(x_mean),       
             col = "red",
             lwd = 0.25)+
  geom_vline(xintercept = lower_bound,      
             col = "blue",
             lwd = 0.25)+
  geom_vline(xintercept = upper_bound,      
             col = "blue",
             lwd = 0.25)+
  labs(title="weigh histogram with mean and confidence interval")+
  geom_text(aes(x=x_mean, label=paste("Mean\n",x_mean), y=1.5),colour="red",size = 3.5)+
 geom_text(aes(x=lower_bound-0.15, label=paste("lower\n bound\n",lower_bound), y=1),colour="blue",size = 3.5)+
geom_text(aes(x=upper_bound+0.15, label=paste("upper\n bound\n",upper_bound), y=1),colour="blue",size = 3.5);
####D
z.test(df_smple$weight,alternative = "greater", mu=1,sigma.x=s ,conf.level = 0.98)
####G
print(paste("population mean",as.character(actual_mean)))
pwr.norm.test(d = actual_mean-null_mean, n = n, sig.level = 0.02,alternative = "greater")
####F
power=0.01603587
beta<-1-power
print(paste("type 2 error: ",as.character(beta)))


#############Q8
###A
x_median=mean(df$weight)
ci=quantile(df$weight, c((1-0.95)/2, 1-(1-0.95)/2 )) 
print(paste("sample mean: ",x_median))
print(paste("mean confidence level using percentile methode:",ci[1],ci[2]))

options(repr.plot.width=15,repr.plot.height=8)
bin_size=(max(df$weight)-min(df$weight))/(sqrt(length(df$weight)))
ggplot(df, aes(x=weight)) +                                
  geom_histogram(aes(y = stat(density)),binwidth = bin_size) +
  
  geom_vline(xintercept = x_median,col = "red",lwd = 0.5, linetype="dotted")+
  geom_vline(xintercept = ci[1],col = "blue",lwd = 0.5, linetype="dotted")+
  geom_vline(xintercept = ci[2],col = "blue",lwd = 0.5,linetype="dotted")+
  labs(title="weigh histogram with median and confidence interval")+
  geom_text(aes(x=x_median, label=paste("mean\n",x_median), y=1.5),colour="red",size = 3.5)+
 geom_text(aes(x=ci[1], label=paste("lower\n bound\n",ci[1]), y=1),colour="blue",size = 3.5)+

 geom_text(aes(x=ci[2], label=paste("upper\n bound\n",ci[2]), y=1),colour="blue",size = 3.5);

###B
df_smple<-df[sample(nrow(df),20),]
B = 1000
n = nrow(df_smple)
boot.samples = matrix(sample(df_smple$weight, size = B * n, replace = TRUE),B, n)
boot.statistics = apply(boot.samples, 1, mean)

n=length(boot.statistics)
s=sd(boot.statistics)
x_mean=mean(boot.statistics)
z=qnorm(1-(1-0.95)/2)
t=qt(1-(1-0.95)/2,n-1)
lower_bound=x_mean-(z * (s/sqrt(n))   )
upper_bound=x_mean+(z * (s/sqrt(n))   )
print(paste("95% confidence interval using CLT methode on bootstrap distribution: ",as.character(lower_bound),",",as.character(upper_bound ),""))

ci=quantile(boot.statistics, c((1-0.95)/2, 1-(1-0.95)/2 )) 
print(paste("mean of bootstrap distribution: ",x_mean))
print(paste("95% confidence interval using percentile methode on bootstrap distribution:",ci[1],ci[2]))

df_boot<-data.frame(boot.statistics)
colnames(df_boot) <- c("sample_mean")
bin_size=(max(df_boot$sample_mean)-min(df_boot$sample_mean))/(sqrt(length(df_boot$sample_mean)))
options(repr.plot.width=8,repr.plot.height=8)
ggplot(df_boot, aes(x = sample_mean))+
geom_dotplot(binwidth = bin_size)+
labs(title="dot plot of mean bootstrap density")



#################Q9
####A
df_smple<-df[sample(nrow(df),200),]
print("variance of each group")
groups_var<-aggregate(x= df_smple$ppage,by = list(df_smple$Q25),FUN = var)
groups_var$closely_following_race<-c("Very closely","Somewhat closely","Not very closely","Not closely at all")
names(groups_var)[names(groups_var) == "x"] <- "age_var"
groups_var
print("mean of each group")
groups_mean<-aggregate(x= df_smple$ppage,by = list(df_smple$Q25),FUN = mean)
groups_mean$closely_following_race<-c("Very closely","Somewhat closely","Not very closely","Not closely at all")
names(groups_mean)[names(groups_mean) == "x"] <- "age_mean"
groups_mean
one_way <- aov(ppage ~ Q25, data = df_smple)
summary(one_way)
#####B
pairwise.t.test(df_smple$ppage, df_smple$Q25, p.adjust.method="bonferroni")

df_watch_somewhat_closely<-df_smple_not[df_smple_not$Q25 == 2,]
s_some<-sd(df_watch_somewhat_closely$ppage)
print(paste("number of group 2 samples: ", as.character(length(df_watch_somewhat_closely$ppage))))

df_watch_very_closely<-df_smple_not[df_smple_not$Q25 == 1,]
s_very<-sd(df_watch_very_closely$ppage)
print(paste("number of group 1 samples: ", as.character(length(df_watch_very_closely$ppage))))


t.test(df_watch_very_closely$ppage, df_watch_somewhat_closely$ppage, sigma.x=s_very,sigma.y=s_not,conf.level = 0.95)

