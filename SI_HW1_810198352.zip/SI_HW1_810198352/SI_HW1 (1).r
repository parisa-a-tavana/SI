##Q7
day_class=c(99,56,78,55.5,32,90,80,81,56,59,45,77,84.5,84,70,72,68,32,79,90)
df_day=data.frame("day_class"=day_class)
night_class=c(98,78,68,83,81,89,88,76,65,45,98,90,80,84.5,85,79,78,98,90,79,81,25.5)
df_night=data.frame("night_class"=night_class)


##a
df_summary_night<-as.data.frame(apply(df_night,2,summary))
df_summary_day<-as.data.frame(apply(df_day,2,summary))
df_summary <- cbind(df_summary_day, df_summary_night)
df_summary

##b
IQR_day=df_summary[[1]][5]-df_summary[[1]][2]
lower_whisker_day=max(df_summary[[1]][2]-1.5*IQR_day, df_summary[[1]][1])
print("day class lower whisker: ")
lower_whisker_day
upper_whisker_day=min(df_summary[[1]][5]+1.5*IQR_day, df_summary[[1]][6])
print("day class upper whisker: ")
upper_whisker_day

IQR_night=df_summary[[2]][5]-df_summary[[2]][2]
lower_whisker_night=max(df_summary[[2]][2]-1.5*IQR_night, df_summary[[2]][1])
print("night class lower whisker: ")
lower_whisker_night
upper_whisker_night=min(df_summary[[2]][5]+1.5*IQR_night, df_summary[[2]][6])
print("night class upper whisker: ")
upper_whisker_night

day_outliers <- cbind( df_day[df_day&day_class<lower_whisker_day,],
                        df_day[df_day&day_class>upper_whisker_day,] )
print(" day class outliers")
day_outliers

night_outliers <- cbind( df_night[df_night&night_class<lower_whisker_night,],
                        df_night[df_night&night_class>upper_whisker_night,] )
print("night class outliers")
night_outliers

##d
boxplot(day_class,night_class,names=c("day_class","night_class"),xlab="score",
        main="Boxplot of day and night students scores",horizontal = TRUE)

##8
##a
diamond=read.csv("D:\\Term7\\Statistical Inference\\hw\\diamonds.csv")
head(diamond)

print("levels of Cut")
levels(diamond$cut)
print("levels of Color")
levels(diamond$color)
print("levels of Clarity")
levels(diamond$clarity)

##b
clarity_table=table(diamond$clarity)
barplot(clarity_table,ylab="number",main="Number of diamonds in each clarity level")


##c
diamond_price=diamond$price
hist(diamond_price)

##d
diamond_clarity=diamond$clarity
b_plot=boxplot(diamond_price ~ diamond_clarity,
               main="Boxplot of diamon_price along diamond_clarity",outcex=0.3,outcol="steelblue") 

##e
color_table=table(diamond$color)
col=rainbow(nlevels(diamond$color))
pie(color_table, labels=paste0(round(color_table/sum(color_table)*100,2),"%"),
    col=col ,main = "Pie Chart of Diamond Colors")
legend("topleft",legend=c('D', 'E', 'F', 'G' ,'H', 'I', 'J'),fill=col) 

##f
plot(x = diamond$depth,y = diamond$price,xlab = "diamon_depth",ylab = "diamond_price",
     main = "Diamond price vs depth", cex = 0.3)
